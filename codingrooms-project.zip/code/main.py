#Import Modules
################
import calendar
import os
import time
##title:rabbitlitious
###backstory: you are a 34 year old living alone in the city. In the middle of a midlife cirisis you buy a rabbit off ebay, to keep you company.Turns out the rabbit has a craving for human flesh so if you do not feed it carrots in the right amount of time, it will eat you.
###this rabbit lives with you in your 2 bed 1 bath apartment and his name is tofu, ironic right?
################
#Define Functions
################
def check_time():
    os.system('clear')
    global minutes
    minutes = minutes + 1
    if minutes >= 15:
        late()
    else:
        print("you have this much time to feed the rabbit:", 15 - minutes, "minutes")
###basically here i set consequences for what happens when you dont feed tofu
def late():
    global day, minutes, haveCarrot, carrotObtained
    print("oops! you didnt feed the rabbit on time\nhe bit your finger off!")
    if day < 5:
        again = input("\nwould you like to try again tomorrow? Say yes or no\n")
        if again.lower() == "yes":
            day = day + 1
            minutes = 0
            haveCarrot = False
            carrotObtained = False
            bedroom()
        else:
            print("\nYeah, You should probably get that finger checked out!")
##i define bedroom, i wanted to add an image but i dont know how to
def bedroom():
    global day
    os.system('clear')
    
    print("\n Goodmorning!\nYou've woken up and you only have 10 min to feed your rabbit!")
    print("\nYou roll out of bed.")
    move = input("\nWhere would you like to go? Say one of these choices:\n\tbathroom\n\tliving room\n\tkitchen\n\trabbits lair\n\tstay here\n")
    if move.lower() == "bathroom":
        bathroom()
    if move.lower()=="kitchen":
        kitchen()
    if move.lower() == "living room":
        living_room()
    if move.lower()=="rabbits lair":
        rabbits_lair()
    elif move.lower() == "stay here":
        bedroom()
    else:
        print("\nsorry, I don't understand, I'll assume you want to stay here")
        time.sleep(1)
        bedroom()
#defined bathroom, added comedy to the script
def bathroom():
    global minutes
    check_time()
    print("\nYou are now in the bathroom.")
    print("\nShould we brush our teeth?")
    move = input("\nSay yes or no\n")
    if move.lower() == "yes":
        print("\nYou brush your teeth and floss")
        print("\nYou STARE at yourself")
        print("\nEw is that a pimple?")
        time.sleep(2)
        print("\nYou pick at it")
        time.sleep(2)
        print("...")
        time.sleep(2)
        print("\nHow long have you been here?")
        time.sleep(2)
        minutes = minutes + 4
        bathroom()
    elif move.lower() == "no":
        print("\nGross.")
        time.sleep(2)
        print("\nUgh.\nAt least wash your face.")
        time.sleep(2)
        print("...")
        minutes = minutes + 1
    move = input("\nWhere would you like to go now? Say one of these choices:\n\tbedroom\n\tliving room\n\tstay here\n")
    if move.lower() == "bedroom":
        bedroom()
    elif move.lower() == "living room":
        living_room()
    else:
        print("\nsorry, I don't understand, I'll assume you want to stay here")
        time.sleep(1)
        bathroom()

## who doesnt love minecraft? i tried to add as many distractions as possible because i get distracted, so i am putting you in my shoes
def living_room():
    global minutes
    check_time()
    print("\nYou turn on the tv for some backround noise.")
    print("\nShould we play minecraft?")
    move = input("\nSay yes or no\n")
    if move.lower() == "yes":
        print("\nYou turn on the Ps5")
        print("\nLets make an exact replica of our room!")
        time.sleep(2)
        print("...")
        time.sleep(2)
        print("...")
        time.sleep(2)
        print("\nHow long have you been here?")
        time.sleep(2)
        minutes = minutes + 5
        living_room()
    elif move.lower() == "no": 
        move = input("\nOk! What would you like to do next? Say one of these choices:\n\tbedroom\n\tbathroom\n\tkitchen\n\trabbits lair\n\tstay here\n")
        if move.lower() == "bedroom":
            bedroom()
        if move.lower() == "bathroom":
            bathroom()
        if move.lower() == "kitchen":
            kitchen()
        if move.lower() == "rabbits lair":
            rabbits_lair()
        elif move.lower() == "stay here":
            living_room()
        else:
            print("\nsorry, I don't understand, I'll assume you want to stay here")
            time.sleep(2)
            living_room()
    

### since the rabbit is a man eating rabbit you need to give him food, here i define rabbits lair, i just want you to imagine a big room with full furniture with a 11 pound bunny living in it
def rabbits_lair():
    global haveCarrot,carrotObtained
    check_time()

    if not haveCarrot:
        print("\nYou are now in your rabbits own personalized bedroom. He lowkey has a better room than you.")
        time.sleep(2)
        print("\nTofu is patiently waiting for his carrot")
        time.sleep(2)
        print("\nYou know that the kitchen has carrots... get a carrot before tofu goes feral!")
        time.sleep(2)
        input("\nPress enter to go back out to the hallway")
        haveCarrot = True
        kitchen()
    elif haveCarrot and not carrotObtained:
        print("\nTofu needs his carrot! What are you waiting for??")
        input("\nPress enter to go back out to the kitchen")
        kitchen()
    else:
        print("You feed Tofu his ultra organic carrot.")
        time.sleep(2)
        print("He happily munches away.")
        time.sleep(2)
        print("Congrats! You fed Tofu on time! Now he wont have to eat you!")
    

   
## made it as realistic as i could...
def kitchen():
    global minutes
    global haveCarrot
    global carrotObtained
    check_time()
    if not haveCarrot:
        print("Welcome to the kitchen!")
    elif haveCarrot and not carrotObtained:
        print("Welcome to the kitchen!")
        print("Theres the fridge, open it and get the carrot.")
        print("You now have a carrot.")
        carrotObtained = True
        print("What would you like to do next?")
    else:
        print("The carrot is getting warm, and you're still in the kitchen. What would you like to do next?")

    move = input("Say one of these choices:\n\tdrink coffee\n\thave a midlife crisis\n\tleave\n")
    if move.lower() == "drink coffee":
        print("you make yourself a cappucino and drink it")
        time.sleep(1)
        print("...")
        time.sleep(1)
        print("...")
        input("Press enter to continue")
        minutes = minutes + 2
        kitchen()
    elif move.lower() == "have a midlife crisis":
        print("you sit down to contemplate your exsistence and lose track of time")
        time.sleep(1)
        print("Do i even like my job?")
        time.sleep(1)
        print("...")
        print ("maybe i should've gotten that eyebrow piercing.")
        input("Press enter to continue")
        minutes = minutes + 5
        kitchen()
    elif move.lower() == "leave":
        rabbits_lair()
    else:
        print("sorry, I don't understand, I'll assume you want to chill here for a bit")
        time.sleep(1)
        kitchen()


################
#Main
################
haveCarrot = False
carrotObtained = False
day = 0
minutes = 0
bedroom()